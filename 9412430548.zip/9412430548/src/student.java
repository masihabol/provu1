
public class student extends javax.swing.JFrame {

    /**
     * Creates new form student
     */
    public String username;
    public String password;

 
    public void settingstudent(String a,String b){
        username=a;
        password=b;
        
    }
    public student() {
        
        initComponents();
    }
    public student(String a,String b){
        username=a;
        password=b;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        newlessone = new javax.swing.JButton();
        all = new javax.swing.JButton();
        joinedlessones = new javax.swing.JButton();
        profile = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton2.setBackground(new java.awt.Color(0, 0, 255));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 255, 51));
        jButton2.setText("ALL LESSONES");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(110, 520, 240, 50);

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 255, 51));
        jButton1.setText("LOG OUT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(483, 600, 140, 40);

        newlessone.setBackground(new java.awt.Color(0, 0, 255));
        newlessone.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        newlessone.setForeground(new java.awt.Color(0, 255, 0));
        newlessone.setText("JOIN NEW LESSON");
        newlessone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newlessoneActionPerformed(evt);
            }
        });
        getContentPane().add(newlessone);
        newlessone.setBounds(110, 370, 240, 50);

        all.setBackground(new java.awt.Color(0, 0, 255));
        all.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        all.setForeground(new java.awt.Color(0, 255, 0));
        all.setText("TOPLESSONES");
        all.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                allMouseClicked(evt);
            }
        });
        all.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                allActionPerformed(evt);
            }
        });
        getContentPane().add(all);
        all.setBounds(110, 470, 240, 50);

        joinedlessones.setBackground(new java.awt.Color(0, 0, 255));
        joinedlessones.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        joinedlessones.setForeground(new java.awt.Color(0, 255, 0));
        joinedlessones.setText("JOINED LESSONES");
        joinedlessones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                joinedlessonesMouseClicked(evt);
            }
        });
        joinedlessones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                joinedlessonesActionPerformed(evt);
            }
        });
        getContentPane().add(joinedlessones);
        joinedlessones.setBounds(110, 320, 240, 50);

        profile.setBackground(new java.awt.Color(0, 0, 255));
        profile.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        profile.setForeground(new java.awt.Color(0, 255, 0));
        profile.setText("PROFILE");
        profile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profileActionPerformed(evt);
            }
        });
        getContentPane().add(profile);
        profile.setBounds(110, 420, 240, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon("E:\\sunset_sea_beach-1366x768.jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1370, 750);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void allMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_allMouseClicked
        // TODO add your handling code here:
        alllessonesinpro le=new alllessonesinpro(username,password);
        dispose();
        le.setVisible(true);
        le.setSize(1400, 721);
    }//GEN-LAST:event_allMouseClicked

    private void allActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_allActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_allActionPerformed

    private void joinedlessonesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_joinedlessonesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_joinedlessonesActionPerformed

    private void joinedlessonesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_joinedlessonesMouseClicked
        // TODO add your handling code here:
        joinedlessones masih=new joinedlessones(username,password);
        dispose();
        masih.setVisible(true);
        masih.setSize(1400,721);
        
    }//GEN-LAST:event_joinedlessonesMouseClicked

    private void newlessoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newlessoneActionPerformed
        // TODO add your handling code here:
                joinnewlessonestudent masih=new joinnewlessonestudent(username,password);
        dispose();
        masih.setVisible(true);
        masih.setSize(1400,721);
        
    }//GEN-LAST:event_newlessoneActionPerformed

    private void profileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileActionPerformed
        // TODO add your handling code here:
        profile masih=new profile(username,password);
        dispose();
        masih.setVisible(true);
        masih.setSize(1400,721);
        
        masih.setting(username, password);
    }//GEN-LAST:event_profileActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        NewJFrame a=new NewJFrame();
       a.setVisible(true);
       dispose();
       a.setSize(1366,720);       
       
       
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new student().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton all;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton joinedlessones;
    private javax.swing.JButton newlessone;
    private javax.swing.JButton profile;
    // End of variables declaration//GEN-END:variables
}
