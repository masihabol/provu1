
import java.awt.GraphicsConfiguration;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class joinedlessones extends javax.swing.JFrame {
    
    String name,password,email;
    ArrayList<String >darsha=new ArrayList<String>();
        public joinedlessones(String a,String b){
        name=a;
        password=b;
        System.out.println(name+"\t\t"+password);
        temp();
    }
public void temp(){
    initComponents();
    System.out.println("name here is :"+name);
            String temp=name.concat(".dat");
        try {
            DataInputStream masih=new DataInputStream(new FileInputStream("E:\\P\\STUDENT\\"+temp));
          /*  String c1=masih.readUTF();
            String c2=masih.readUTF();
            String c3=masih.readUTF();
            System.out.println(c1+"\t"+c2+"\t"+c3);*/
            while(masih.available()>0){
                String temps=masih.readUTF();
                darsha.add(temps);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(joinedlessones.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(joinedlessones.class.getName()).log(Level.SEVERE, null, ex);
        }
           String []w=new String[1000];
    
 
       System.out.println("number of your lessones are :"+darsha.size());
    for(int i=3;i<darsha.size();i++)
    {
        w[i]=darsha.get(i);
        System.out.println(w[i]+"-----------");
    }
  
    System.out.println(name+"\t\t"+password);
       jList1.setListData(w);
       System.out.println(name);
       
}
  
    public joinedlessones() {
        temp();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton2.setText("back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(160, 470, 55, 23);

        jButton1.setText("jButton1");
        getContentPane().add(jButton1);
        jButton1.setBounds(490, 480, 73, 23);

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(450, 200, 190, 190);

        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 0, 1120, 660);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        student masih=new student(name,password);
        dispose();
        masih.setVisible(true);
        masih.setSize(1400,721);
    }//GEN-LAST:event_jButton2ActionPerformed
    public void setting(String a,String b){
        name=a;
        password=b;       
}
  

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(joinedlessones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(joinedlessones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(joinedlessones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(joinedlessones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new joinedlessones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JList jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
