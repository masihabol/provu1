import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class assignment extends javax.swing.JFrame {
    private int a = 0;
    public String lessone;
    public assignment() {
        temp();
       
    }
    
    public assignment(String b){
        lessone=b;
        temp();
    }
    public void temp() {
        initComponents();
        jTextField1.setVisible(false);
        jTextArea1.setVisible(false);
        jFileChooser1.setVisible(false);
        icon.setVisible(false);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        icon = new javax.swing.JLabel();
        jFileChooser1 = new javax.swing.JFileChooser();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        dateChooserPanel1 = new datechooser.beans.DateChooserPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton3.setText("POST");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(930, 610, 190, 40);

        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attach_96px.png"))); // NOI18N
        icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iconMouseClicked(evt);
            }
        });
        getContentPane().add(icon);
        icon.setBounds(810, 600, 220, 80);
        getContentPane().add(jFileChooser1);
        jFileChooser1.setBounds(340, 217, 680, 370);

        jTextField1.setText("jTextField1");
        getContentPane().add(jTextField1);
        jTextField1.setBounds(630, 150, 510, 40);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(630, 210, 510, 340);

        jButton2.setText("ALL POSTS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(120, 470, 170, 50);

        jButton1.setText("NEW POST");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(120, 340, 170, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/electromagnetic_spectrum-1366x768.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(4, 0, 1370, 710);
        getContentPane().add(dateChooserPanel1);
        dateChooserPanel1.setBounds(100, 70, 250, 180);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jTextField1.setVisible(true);
        jTextArea1.setVisible(true);
        icon.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void iconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconMouseClicked
        // TODO add your handling code here:
        if (a % 2 == 0) {
            jFileChooser1.setVisible(true);
            a++;
        } else {
            jFileChooser1.setVisible(false);
            a++;
        }
        String a=jTextArea1.getText();
                System.out.println("wow");
        System.out.println(a);
    }//GEN-LAST:event_iconMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
allposts masih=new allposts(lessone);
masih.setVisible(true);
       
        dispose();
        masih.setSize(1400,720);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

//        String temp=lessone.concat("post.dat");
           String b=jTextField1.getText();
           String a=jTextArea1.getText();
           String temp2=b.concat(".dat");
           File c=new File(a);
           c.mkdir();
           DataOutputStream f;
           DataOutputStream g;
        try {
            f = new DataOutputStream(new FileOutputStream("posts\\temp.txt",true));
            g = new DataOutputStream(new FileOutputStream("posts\\"+temp2));
               try {
                   g.writeUTF(a);
               } catch (IOException ex) {
                   Logger.getLogger(assignment.class.getName()).log(Level.SEVERE, null, ex);
               }
               try {
                   f.writeUTF(b);
               } catch (IOException ex) {
                   Logger.getLogger(assignment.class.getName()).log(Level.SEVERE, null, ex);
               }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(assignment.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("wow");
        System.out.println(a);
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(assignment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(assignment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(assignment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(assignment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new assignment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private datechooser.beans.DateChooserPanel dateChooserPanel1;
    private javax.swing.JLabel icon;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
