
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
public class NewJFrame extends javax.swing.JFrame {
    public int a=-1;
    public int sw=0;
    public int music=-1;
   
    public NewJFrame() {
        temp();
        
    }
        void showdate(){
        Date d=new Date();
        SimpleDateFormat a=new SimpleDateFormat("YYYY-MM-dd");
        jLabel7.setText(a.format(d));
    }
    void showtime(){
        new Timer(0,new ActionListener(){
        @Override
            public void actionPerformed(ActionEvent e) {
        Date d=new Date();
        SimpleDateFormat a=new SimpleDateFormat("hh:mm:ss a");
        jLabel6.setText(a.format(d));
            }
            
        }).start();
        System.out.println("heloo");
    }
    public void temp(){
        initComponents();
        jProgressBar1.setVisible(false);
        showtime();
        showdate();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jMenuItem1 = new javax.swing.JMenuItem();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        student = new javax.swing.JRadioButton();
        teacher = new javax.swing.JRadioButton();
        register = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jLabel5 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jTextArea2.setText("Welcome TO PIAZZA DR NOORI");
        jScrollPane2.setViewportView(jTextArea2);

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 255, 51));
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(930, 600, 200, 50);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 255, 0));
        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(320, 594, 190, 60);

        jProgressBar1.setBackground(new java.awt.Color(102, 102, 255));
        jProgressBar1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jProgressBar1StateChanged(evt);
            }
        });
        getContentPane().add(jProgressBar1);
        jProgressBar1.setBounds(820, 530, 250, 40);

        jButton2.setBackground(new java.awt.Color(0, 0, 204));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Audio-File-icon.png"))); // NOI18N
        jButton2.setText("jButton2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(320, 510, 90, 70);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("confirm");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(600, 530, 140, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setText("WELCOME");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(326, 48, 227, 110);
        getContentPane().add(jLabel3);
        jLabel3.setBounds(62, 23, 0, 0);

        buttonGroup1.add(student);
        student.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        student.setForeground(new java.awt.Color(51, 255, 51));
        student.setText("STUDENT");
        student.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentActionPerformed(evt);
            }
        });
        getContentPane().add(student);
        student.setBounds(610, 310, 110, 31);

        buttonGroup1.add(teacher);
        teacher.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        teacher.setForeground(new java.awt.Color(51, 255, 51));
        teacher.setText("TEACHER");
        teacher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherActionPerformed(evt);
            }
        });
        getContentPane().add(teacher);
        teacher.setBounds(610, 380, 110, 31);

        buttonGroup1.add(register);
        register.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        register.setForeground(new java.awt.Color(102, 255, 102));
        register.setText("REGISTER");
        register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerActionPerformed(evt);
            }
        });
        getContentPane().add(register);
        register.setBounds(610, 450, 110, 31);

        jLabel4.setIcon(new javax.swing.ImageIcon("E:\\conference.png")); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(610, 150, 180, 140);

        jLabel1.setForeground(new java.awt.Color(51, 255, 51));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/4.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1400, 770);
        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(470, 230, 2, 170);
        getContentPane().add(jScrollPane3);
        jScrollPane3.setBounds(360, 340, 2, 100);
        getContentPane().add(jDesktopPane1);
        jDesktopPane1.setBounds(160, 210, 0, 0);

        jLabel5.setText("jLabel5");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(460, 190, 90, 30);

        jRadioButton1.setText("jRadioButton1");
        getContentPane().add(jRadioButton1);
        jRadioButton1.setBounds(650, 280, 93, 23);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void studentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentActionPerformed
        // TODO add your handling code here:
       /* Register masih=new Register();
        masih.setVisible(true);
        this.setVisible(false);*/
      
        a=1;
        sw++;
       
        InputStream in;
       /* try{
            in=new FileInputStream(new File("E:\\Hamid Askari - Del Del Nakon Be Raftan.wav"));
            AudioStream a=new AudioStream(in);
            AudioPlayer.player.start(a);
            
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }*/
                try{
            in=new FileInputStream(new File("E:\\student_1_.wav"));
            AudioStream a=new AudioStream(in);
            
            AudioPlayer.player.start(a);
           }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
    }//GEN-LAST:event_studentActionPerformed

    private void registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerActionPerformed
        // TODO add your handling code here:
       a=2;
               InputStream in;
                try{
            in=new FileInputStream(new File("E:\\register.wav"));
            AudioStream a=new AudioStream(in);
            
            AudioPlayer.player.start(a);
           }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_registerActionPerformed

    private void teacherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherActionPerformed
        // TODO add your handling code here:
        a=0;
                       InputStream in;
                try{
            in=new FileInputStream(new File("E:\\teacher_1_.wav"));
            AudioStream a=new AudioStream(in);
            
            AudioPlayer.player.start(a);
           }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_teacherActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:\
            NewJFrame mas=new NewJFrame();
         teacher sara=new teacher();
        Register b=new Register();
        student mahdi=new student();
        menustudet mnu=new menustudet();
        checkpass pass=new checkpass();
        cps stu=new cps();
         jProgressBar1.setVisible(true);

//** add this into your application code as appropriate
// Open an input stream  to the audio file.
         FileInputStream in;
                try{
            in=new FileInputStream(new File("E:\\loading.wav"));
            AudioStream a=new AudioStream(in);
            
            AudioPlayer.player.start(a);
           }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
                Thread t = new Thread(new Runnable(){
            public void run()
            {
              
                for(int i=0;i<=100;i++)
                {
                    
                    // Loop it forever
                    
                    // Update value
                    jProgressBar1.setValue(i);
                    try
                    {
                        // Get the effect
                        Thread.sleep(20);
                    }catch(Exception e){}
                    if(i==100){
                                if(a==0)
        {                         
            pass.setVisible(true);
            pass.setSize(1400,1400);
            dispose();   
        }
        if(a==2)
        {
            b.setVisible(true);
            b.setSize(1400,1400);
            dispose();
            
        }
        if(a==1){
           stu.setVisible(true);
            stu.setSize(1400, 1400);
            dispose();     
        }
                                    }
                    
                                
              }   }
        });
 // Start thread
   t.start();

      

        
        
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
                    
                InputStream in;
            try{
            in=new FileInputStream(new File("E:\\Hamid Askari - Del Del Nakon Be Raftan.wav"));
            AudioStream a=new AudioStream(in);
            if(music==-1){
                
            AudioPlayer.player.start(a);
               
            }
            
           }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jProgressBar1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jProgressBar1StateChanged
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jProgressBar1StateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
            ColorUIResource colorResource = new ColorUIResource(Color.green.brighter().brighter());
            UIManager.put("nimbusOrange",colorResource);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
                try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
                 public void run() {
                JFrame masih=new NewJFrame();
                masih.setVisible(true);
                masih.setSize(1400,1400);
                
                }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JRadioButton register;
    private javax.swing.JRadioButton student;
    private javax.swing.JRadioButton teacher;
    // End of variables declaration//GEN-END:variables
}
