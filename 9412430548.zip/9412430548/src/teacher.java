public class teacher extends javax.swing.JFrame {
    public static String password,username;
    public void setting(String a,String b){
        username=a;
        password=b;
    }
    public void  temp(){
        initComponents();
        jLabel2.setText("HI    "+username);
    }
    public teacher() {
        temp();
    }
    public teacher(String name,String pass){
        password=pass;
        username=name;
        temp();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        back = new javax.swing.JButton();
        lessone = new javax.swing.JButton();
        manage = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
        });
        getContentPane().setLayout(null);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(700, 70, 220, 50);

        jButton2.setBackground(new java.awt.Color(0, 0, 255));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton2.setText("EDIT PROFILE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(130, 410, 300, 60);

        back.setBackground(new java.awt.Color(0, 51, 255));
        back.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        back.setText("back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(140, 540, 120, 37);

        lessone.setBackground(new java.awt.Color(51, 51, 255));
        lessone.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lessone.setText("making new lessones");
        lessone.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lessoneMouseClicked(evt);
            }
        });
        lessone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lessoneActionPerformed(evt);
            }
        });
        getContentPane().add(lessone);
        lessone.setBounds(130, 140, 300, 70);

        manage.setBackground(new java.awt.Color(51, 0, 255));
        manage.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        manage.setText("management of current lessones  ");
        manage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                manageMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                manageMouseEntered(evt);
            }
        });
        manage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manageActionPerformed(evt);
            }
        });
        getContentPane().add(manage);
        manage.setBounds(130, 270, 301, 70);

        logout.setBackground(new java.awt.Color(0, 0, 204));
        logout.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        logout.setText("logout");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        getContentPane().add(logout);
        logout.setBounds(300, 540, 120, 37);

        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 0, 34, 14);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rainbow_above_clouds-wallpaper-1366x768.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1550, 730);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void manageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageActionPerformed

    }//GEN-LAST:event_manageActionPerformed

    private void lessoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lessoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lessoneActionPerformed

    private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_formMouseClicked

    private void lessoneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lessoneMouseClicked
        // TODO add your handling code here:
      
        newlessone2 le=new newlessone2(username, password);
        dispose();
        le.setVisible(true);
        le.setSize(1400,1400);
    }//GEN-LAST:event_lessoneMouseClicked

    private void manageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_manageMouseClicked
        // TODO add your handling code here:

        lessonesofteacher ostad=new lessonesofteacher(username,password);
        dispose();
        ostad.setVisible(true);
        ostad.setSize(1400,1400);
        ostad.setting(username, password);
        
    }//GEN-LAST:event_manageMouseClicked

    private void manageMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_manageMouseEntered
        // TODO add your handling code here:
        System.out.println("entered");
    }//GEN-LAST:event_manageMouseEntered

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        checkpass cps=new checkpass();
        dispose();
        cps.setVisible(true);
        cps.setSize(1400, 720);
    }//GEN-LAST:event_backActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        // TODO add your handling code here:
        NewJFrame start=new NewJFrame();
        dispose();
        start.setVisible(true);
        start.setSize(1400,720);
    }//GEN-LAST:event_logoutActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        profile2 masih=new profile2(username,password);
        dispose();
        masih.setVisible(true);
        masih.setSize(1400,720);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(teacher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(teacher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(teacher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(teacher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new teacher().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JButton lessone;
    private javax.swing.JButton logout;
    private javax.swing.JButton manage;
    // End of variables declaration//GEN-END:variables
}
