import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.chart.PieChart.Data;
public class newlessone2 extends javax.swing.JFrame {

    /**
     * Creates new form newlessone2
     */
    public static String id,password;
    public newlessone2() {
        initComponents();
    }
    public newlessone2(String username,String pass){
        id=username;
        password=pass;
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        confirm = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton2.setText("back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(760, 350, 120, 30);

        jTextField2.setBackground(new java.awt.Color(153, 255, 0));
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField2);
        jTextField2.setBounds(580, 140, 180, 40);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 255));
        jLabel3.setText("code of lessone");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(260, 140, 190, 40);

        jButton1.setBackground(new java.awt.Color(102, 255, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 255));
        jButton1.setText("confirm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(180, 400, 170, 40);

        jTextField1.setBackground(new java.awt.Color(102, 255, 0));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(580, 60, 180, 40);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 102, 255));
        jLabel2.setText("new lessone");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel2);
        jLabel2.setBounds(260, 50, 290, 50);

        confirm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sunset_with_small_islands-wallpaper-1366x768.jpg"))); // NOI18N
        confirm.setText("jLabel1");
        getContentPane().add(confirm);
        confirm.setBounds(0, -20, 1520, 810);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        teacher te=new teacher();
        dispose();
        te.setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {                                         
            String t1=jTextField1.getText();
            String t2=jTextField2.getText();
            DataOutputStream te;
            String temp=id.concat(".dat");
            te = new DataOutputStream(new FileOutputStream("teacher\\"+temp,true));
            try {
                te.writeUTF(t1);
            } catch (IOException ex) {
                Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
            }
            DataOutputStream codes =null;
            try {
                DataOutputStream lessonplacing =null;
                
                codes = new DataOutputStream(new FileOutputStream("lessones\\cod\\codes.txt",true));
                try {
                    codes.writeUTF(t1);
                    
                } catch (IOException ex) {
                    Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    codes.writeUTF(t2);
                } catch (IOException ex) {
                    Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    DataOutputStream output2 =null;
                    
                    String a =jTextField1.getText();
                    String temp1=jTextField1.getText();
                    String temp2=temp1.concat(".dat");
                    String temp3=temp1.concat("post.dat");
                    lessonplacing = new DataOutputStream(new FileOutputStream("lessones\\"+temp2,true));
                    try {
                        lessonplacing.writeUTF(id);
                    } catch (IOException ex) {
                        Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    DataOutputStream postsplacing=new DataOutputStream((new FileOutputStream("lessones\\"+temp3,true)));
                    
                    try {
                        DataOutputStream output =null;
                        File f = new File("C:\\test.txt");
                        File f2       =new File("tea.dat");
                        output2 = new DataOutputStream(new FileOutputStream("E://masihabol.txt",true));
                        try {
                            // TODO add your handling code here:
                            
                            String nameoffile=a.concat(".dat");
                            output = new DataOutputStream(new FileOutputStream(nameoffile,true));
                        } catch (FileNotFoundException ex) {
                            Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                        } finally {
                            try {
                                output.close();
                            } catch (IOException ex) {
                                Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                    } finally {
                        try {
                            output2.close();
                        } catch (IOException ex) {
                            Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                } finally {
                    try {
                        lessonplacing.close();
                    } catch (IOException ex) {
                        Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    codes.close();
                } catch (IOException ex) {
                    Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(newlessone2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        teacher ostad=new teacher(id,password);
        dispose();
        ostad.setVisible(true);
        ostad.setSize(1400,720);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(newlessone2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(newlessone2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(newlessone2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(newlessone2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new newlessone2().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel confirm;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
