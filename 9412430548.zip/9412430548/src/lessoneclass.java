/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NotBook
 */
import java.util.ArrayList;
public class lessoneclass {
    ArrayList<studentclass >student=new ArrayList<studentclass>();
    public int units;
    public String name;
    public String code;
    public String teacher;
    public lessoneclass(String a,String b,String c,int d){
        name=a;
        code=b;
        teacher=c;
        units=d;
    }
    public void setname(String a){
        name=a;
    }
        public void setcode(String a){
        code=a;
    }
            public void setunits(int a){
        units=a;
    }
                public void setteacher(String a){
        teacher=a;
    }
   public String getname (){
       return name;
   }
    public String getcode (){
       return code;
   }
   public String getteacher(){
       return teacher;
   }
   public int getunit(){
       return units;
   }
   public void addstudent(studentclass a){
       student.add(a);
   }
   public void removestudent(studentclass a){
       student.remove(a);
       a.lessonesofstudent.remove(name);
   }
   
}
