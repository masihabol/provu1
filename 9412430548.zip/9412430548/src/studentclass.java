/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NotBook
 */


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NotBook
 */
import java.util.ArrayList;
public class studentclass {
    public double average;
    public int units ;
    public String email;
    public String username;
    public String password;
   ArrayList<String> lessonesofstudent=new ArrayList<String>();
   
    public studentclass(String a,String b,String c){
        email=a;
        username=b;
        password=c;
     
    }
    
    public double getaverage(){
        return average;
    }
    public int  getunits(){
        return units;
    }
    public String getemail(){
        return email;
    }
    public String password(){
        return password;
    }
    public String getusername(){
      return username;
    }
    public void setaverage(double a){
        average=a;
    }
    public void setunits(int a){
        units=a;
    }
    public void setname(String temp){
        email=temp;
    }
    public void setusername(String temp){
        username=temp;
    }
    
    
    
    
}
