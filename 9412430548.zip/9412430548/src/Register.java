import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.String;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.io.DataOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.Timer;
public class Register extends javax.swing.JFrame  {
public Register() {
        temp();
    }
public void temp(){
    initComponents();
    error.setVisible(false);
    showtime();
    showdate();
    invite.setVisible(false);
}
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        invite = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        mail = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        error = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        pass = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        student = new javax.swing.JButton();
        teacher = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        invite.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        invite.setForeground(new java.awt.Color(255, 255, 0));
        invite.setText("we have sent you an invitation email");
        getContentPane().add(invite);
        invite.setBounds(524, 604, 500, 30);

        date.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        date.setForeground(new java.awt.Color(0, 255, 0));
        date.setText("jLabel7");
        getContentPane().add(date);
        date.setBounds(420, 660, 230, 40);

        time.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        time.setForeground(new java.awt.Color(0, 255, 0));
        time.setText("jLabel7");
        getContentPane().add(time);
        time.setBounds(0, 660, 220, 40);

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 204, 102));
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(80, 80, 100, 40);

        mail.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        mail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mailActionPerformed(evt);
            }
        });
        getContentPane().add(mail);
        mail.setBounds(640, 240, 310, 50);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 204, 102));
        jLabel6.setText("EMAIL");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(320, 240, 180, 50);

        id.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(640, 70, 310, 50);

        error.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        error.setForeground(new java.awt.Color(255, 255, 0));
        error.setText("sorry the username you entered already exits");
        getContentPane().add(error);
        error.setBounds(530, 600, 510, 40);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 204, 102));
        jLabel2.setText("PASSWORD");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(320, 140, 220, 80);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 102));
        jLabel1.setText("USERNAME");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(320, 80, 300, 30);

        pass.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passActionPerformed(evt);
            }
        });
        getContentPane().add(pass);
        pass.setBounds(640, 150, 310, 50);

        jLabel4.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 204, 102));
        jLabel4.setText("register as :");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(540, 450, 170, 40);

        student.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        student.setText("student");
        student.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentActionPerformed(evt);
            }
        });
        getContentPane().add(student);
        student.setBounds(710, 420, 120, 37);

        teacher.setFont(new java.awt.Font("Tahoma", 2, 24)); // NOI18N
        teacher.setText("teacher");
        teacher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherActionPerformed(evt);
            }
        });
        getContentPane().add(teacher);
        teacher.setBounds(710, 480, 120, 37);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/abstract_3d_art_85489_1920x1080.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(0, 0, 1390, 710);

        jLabel5.setText("jLabel5");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(210, 200, 210, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents
        void showdate(){
        Date d=new Date();
        SimpleDateFormat a=new SimpleDateFormat("YYYY-MM-dd");
        date.setText(a.format(d));
    }
    void showtime(){
        new Timer(0,new ActionListener(){
        @Override
            public void actionPerformed(ActionEvent e) {
        Date d=new Date();
        SimpleDateFormat a=new SimpleDateFormat("hh:mm:ss a");
        time.setText(a.format(d));
            }
            
        }).start();
        System.out.println("heloo");
    }
    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
        JLabel a=new JLabel();
        a.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        a.setText("PASSWORD");
                getContentPane().add(a);    
    }//GEN-LAST:event_idActionPerformed

    private void passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passActionPerformed

    private void studentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentActionPerformed
        // TODO add your handling code here:
                ArrayList<String>users=new ArrayList<>();
        ArrayList<String>passwords=new ArrayList<>();
        ArrayList <String >emails=new ArrayList<>();
        int temp=1;
        String name=id.getText();
        String password=pass.getText();
        String email=mail.getText();
 try {
        DataInputStream input = new DataInputStream(new FileInputStream("student.dat"));
                    int sw=1;
                    student daneshamooz=new student();
                    while(input.available()>0){
                        
                    String tempuser=input.readUTF();
                    String temppass=input.readUTF();
                    String tempemail=input.readUTF();
                    users.add(tempuser);
                    passwords.add(temppass);}
                    for(int i=0;i<users.size();i++){
                        if(name.compareTo(users.get(i))==0&&password.compareTo(passwords.get(i))==0)
                        { 
                            System.out.println("no");
                            error.setVisible(true);
                            sw=0;
                            break;
                        }
                        else{
                            error.setVisible(false);
                        }       
            }
                    if(sw==1){
                        invite.setVisible(true);
                        daneshamooz.setVisible(true);
                        dispose();
                        daneshamooz.setSize(1400,1400);
                       
                    }               
    } catch (FileNotFoundException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    } 
                try {
        DataOutputStream output = new DataOutputStream(new FileOutputStream("student.dat",true));

        for(int i=0;i<users.size();i++){
            if(name.compareTo(users.get(i))==0&&password.compareTo(passwords.get(i))==0){
                System.out.println("hello");
                temp=0;
            }
            }
        if(temp==1) {
        output.writeUTF(name);
        output.writeUTF(password);
        output.writeUTF(email);
                studentclass osta;
                
            osta= new studentclass( email,name,password);

            String concatination=name.concat(".dat");
            DataOutputStream outs = new DataOutputStream(new FileOutputStream("student\\"+concatination,true));
            outs.writeUTF(osta.getusername());
            outs.writeUTF(osta.password());
            outs.writeUTF(osta.getemail());
            for(int i=0;i<osta.lessonesofstudent.size();i++){
                outs.writeUTF(osta.lessonesofstudent.get(i));
                
            }
            
                }  
    } catch (FileNotFoundException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    }   
    }//GEN-LAST:event_studentActionPerformed

    private void teacherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherActionPerformed

        ArrayList<String>users=new ArrayList<>();
        ArrayList<String>passwords=new ArrayList<>();
        ArrayList<String>emails=new ArrayList<>();
        int temp=1;
        String name=id.getText();
        String password=pass.getText();
        String email=mail.getText();
 try {
        DataInputStream input = new DataInputStream(new FileInputStream("teacher.dat"));
                    int sw=1;
                    teacher ostad=new teacher();
                    while(input.available()>0){
                        
                    String tempuser=input.readUTF();
                    String temppass=input.readUTF();
                    String tempemail=input.readUTF();
                    users.add(tempuser);
                    passwords.add(temppass);}
                    for(int i=0;i<users.size();i++){
                        if(name.compareTo(users.get(i))==0&&password.compareTo(passwords.get(i))==0&&email.compareTo(emails.get(i))==0)
                        { 
                            System.out.println("no");
                            error.setVisible(true);
                            sw=0;
                            break;
                        }
                        else{
                            error.setVisible(false);
                        }       
            }
                    if(sw==1){
                        invite.setVisible(true);
                        ostad.setVisible(true);
                        dispose();
                        ostad.setSize(1400,1400);
                       
                    }               
    } catch (FileNotFoundException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    } 
                try {
        DataOutputStream output = new DataOutputStream(new FileOutputStream("teacher.dat",true));

        for(int i=0;i<users.size();i++){
            if(name.compareTo(users.get(i))==0&&password.compareTo(passwords.get(i))==0){
                System.out.println("hello");
                temp=0;
            }
            }
        if(temp==1) {
        output.writeUTF(name);
        output.writeUTF(password);
        output.writeUTF(email);
        teacherclass osta;
            osta= new teacherclass( email,name,password);
            
            String concatination=name.concat(".dat");
            DataOutputStream outs = new DataOutputStream(new FileOutputStream("E:\\P\\TEACHERS\\"+concatination,true));
            outs.writeUTF(osta.getusername());
            outs.writeUTF(osta.password());
            outs.writeUTF(osta.getemail());
            for(int i=0;i<osta.lessonesofstudent.size();i++){
                outs.writeUTF(osta.lessonesofstudent.get(i));
            }
                }  
    } catch (FileNotFoundException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
    }       
    }//GEN-LAST:event_teacherActionPerformed

    private void mailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mailActionPerformed
       
    }//GEN-LAST:event_mailActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        NewJFrame pic=new NewJFrame();
        dispose();
        pic.setVisible(true);
        pic.setSize(1400,700);
    }//GEN-LAST:event_jButton1ActionPerformed
public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel date;
    private javax.swing.JLabel error;
    private javax.swing.JTextField id;
    private javax.swing.JLabel invite;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField pass;
    private javax.swing.JButton student;
    private javax.swing.JButton teacher;
    private javax.swing.JLabel time;
    // End of variables declaration//GEN-END:variables
}
